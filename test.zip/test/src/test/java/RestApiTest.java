package com.example.tests;

import static io.restassured.RestAssured.get;

import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.testng.annotations.Test;

public class RestApiTest {

    @Test(description = "API GET REQUEST TEST")
    public void getRequestExampleTest() throws JSONException {
        Response response = get("https://api.vk.com/method/friends.get?v=5.52&access_token=993ad8324ee8d57b469e6dd3fe356066a8fe6e911212e8f9c2cfe086d683fa81098dd7b6bf165b7b55063");
        JSONArray jsonResponse = new JSONArray(response.asString());
        String friends = jsonResponse.getJSONObject(0).getString("id");
        System.out.println('\n' + friends);
    }
}
